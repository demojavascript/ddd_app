package com.app.preetaharit.activities.adapters;

/**
 * Created by Rahul on 10-01-2016.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.preetaharit.R;
import com.app.preetaharit.activities.models.CNotification;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class NoteGridAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<CNotification> allNote;
    @Override
    public int getCount() {
        return allNote.size();
    }

    public NoteGridAdapter(Context c, ArrayList<CNotification> allNote) {
        mContext = c;
        this.allNote = allNote;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View grid;
        final LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            grid = new View(mContext);
            grid = inflater.inflate(R.layout.grid_notification, null);
            ImageView img_photo = (ImageView) grid.findViewById(R.id.img_banner);
            TextView tv_title = (TextView)grid.findViewById(R.id.tv_title);
            TextView tv_desc = (TextView)grid.findViewById(R.id.tv_desc);
            final CNotification cnote = allNote.get(position);
            tv_title.setText(cnote.getTitle());
            tv_desc.setText(cnote.getDesc());
            if(cnote.getBannerimg() != null && cnote.getBannerimg().length() > 0) {
                img_photo.setVisibility(View.VISIBLE);
                Picasso.with(mContext).load(cnote.getBannerimg()).into(img_photo);
            }

        } else {
            grid = (View) convertView;
        }
        return grid;
    }
}