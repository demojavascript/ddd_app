package com.app.preetaharit.activities.models;

/**
 * Created by Rahul on 29-08-2017.
 */

public class CNotification {
    private String id;
    private String title;
    private String desc;
    private String bannerimg;
    private String sdate;
    public CNotification(){

    }
    public CNotification(String id, String title, String desc, String bannerimg, String sdate){
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.bannerimg = bannerimg;
        this.sdate = sdate;
    }
    public String getId(){
        return this.id;
    }
    public String getTitle(){
        return this.title;
    }
    public String getDesc(){
        return this.desc;
    }
    public String getBannerimg(){
        return this.bannerimg;
    }
    public String getSdate(){
        return this.sdate;
    }
}
