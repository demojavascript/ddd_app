package com.app.preetaharit.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;

import com.app.preetaharit.R;
import com.app.preetaharit.activities.adapters.NoteGridAdapter;
import com.app.preetaharit.activities.gridviews.NoteGridView;
import com.app.preetaharit.activities.models.CNotification;

import java.util.ArrayList;

public class NotificationsActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private NoteGridAdapter noteGridAdapter;
    private NoteGridView noteGridView;
    private ArrayList<CNotification> allNote;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Notifications");
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        showNote();
    }

    private void showNote(){
        allNote = new ArrayList<CNotification>();
        for(int i=0;i<4; i++){
            String imgurl = "";
            if(i%2 == 0){
                imgurl = "https://scontent.fdel1-2.fna.fbcdn.net/v/t1.0-0/p480x480/21032359_1712577695718162_9018000375624096068_n.jpg?oh=0b96c7e40db254b7a64856eeda1fe998&oe=5A1843E5";
            }
            CNotification nott = new CNotification("id_"+i, "सशक्त नारी सुदृढ़ समाज का आधार होती है।"+i, "अतः नारी शिक्षा एवं सशक्तिकरण की दिशा में मैडम प्रीता हरित के अतुल्य विचारों से रुबरु होने का स्वर्णिम अवसर।\n" +
                    "अधिक से अधिक संख्या में पहुंचकर मैडम के विचारों व आदर्शों को सुनें।\n" +
                    "जय भीम, जय भारत।", imgurl, "");
            allNote.add(nott);
        }
        noteGridAdapter = new NoteGridAdapter(this, allNote);
        noteGridView = (NoteGridView) findViewById(R.id.gridNote);
        noteGridView.setNumColumns(1);
        noteGridView.setAdapter(noteGridAdapter);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
